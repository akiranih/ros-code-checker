import time

def main():
    print("Starting example ROS node...")
    for i in range(5):
        print(f"Publishing message {i}")
        time.sleep(0.5)

if __name__ == "__main__":
    main()
