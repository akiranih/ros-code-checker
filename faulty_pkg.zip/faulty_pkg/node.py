def main()
    print("This node has a syntax error")
